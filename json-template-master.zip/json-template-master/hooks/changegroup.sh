#!/bin/bash
#
# Mercurial hooks run with their working dir as the root of the repository.
#
# To install this hook, put this in .hg/hgrc
#
# [hooks]
# changegroup = hooks/changegroup.sh

/poly/tools/chubot-vcs-hook-cdi
