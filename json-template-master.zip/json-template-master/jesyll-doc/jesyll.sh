#!/bin/bash
#
# jesyll.sh
# Author: Andy Chu

../../../git/narwhal-v8/nw.sh $PWD/../../../git/jesyll/bin/jesyll $PWD
