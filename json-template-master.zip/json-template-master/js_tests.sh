#!/bin/bash
# Run standalone JavaScript tests
#
#Load the test framework, then JSON Template, then the tests

javascript/v8shell/linux-i686/shell javascript/jsunity-0.6.js javascript/json-template.js javascript/json-template-test.js
