package jsontemplate;

public interface ITemplateRenderCallback {
	void templateDidRender(String renderedString);
}
