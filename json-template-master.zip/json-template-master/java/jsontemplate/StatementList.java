package jsontemplate;

import java.util.ArrayList;

@SuppressWarnings("serial")
class StatementList extends ArrayList<IStatement> {

}
